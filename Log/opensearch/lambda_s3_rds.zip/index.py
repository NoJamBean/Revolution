import base64
import json
import re
import datetime

def lambda_handler(event, context):
    output_records = []

    for record in event['records']:
        try:
            payload_decoded = base64.b64decode(record['data']).decode('utf-8')

            # 매우 기본적인 파싱 예시 (실제 로그 형식에 맞게 정교화 필요)
            parsed_data = {
                'original_log': payload_decoded,
                '@timestamp': datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ'),
                'message': payload_decoded
            }

            # 간단한 정규식으로 타임스탬프와 메시지 분리 시도 (예시)
            match_z = re.match(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z)\s+(\d+)\s+(.*)', payload_decoded)
            match_nodate = re.match(r'(\d{6}\s+\d{2}:\d{2}:\d{2})\s+(\d+)\s+(Query|Connect|Quit|Init DB)\s+(.*)', payload_decoded, re.IGNORECASE)

            if match_z:
                parsed_data['@timestamp'] = match_z.group(1)
                parsed_data['thread_id'] = match_z.group(2)
                parsed_data['message'] = match_z.group(3).strip()
            elif match_nodate:
                try:
                    log_time_str = match_nodate.group(1)
                    current_year = datetime.datetime.utcnow().year
                    log_dt = datetime.datetime.strptime(f"{current_year}{log_time_str}", "%Y%y%m%d %H:%M:%S")
                    parsed_data['@timestamp'] = log_dt.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
                except ValueError:
                    pass # 파싱 실패 시 기본 타임스탬프 유지
                parsed_data['thread_id'] = match_nodate.group(2)
                parsed_data['log_type'] = match_nodate.group(3).strip()
                parsed_data['message'] = match_nodate.group(4).strip()

            output_record = {
                'recordId': record['recordId'],
                'result': 'Ok',
                'data': base64.b64encode(json.dumps(parsed_data).encode('utf-8')).decode('utf-8')
            }
            output_records.append(output_record)

        except Exception as e:
            print(f"Error processing record {record.get('recordId', 'N/A')}: {e}")
            output_record = {
                'recordId': record.get('recordId', 'N/A'),
                'result': 'ProcessingFailed',
                'data': record['data'] # 원본 데이터 반환
            }
            output_records.append(output_record)

    print(f"Processed {len(output_records)} records.")
    return {'records': output_records}
