import json
import base64
import logging
import gzip # gzip 모듈 임포트 추가

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):

    output_records = []

    for record in event['records']:
        record_id = record['recordId'] # record_id 변수 정의
        try:
            # 1. 레코드 데이터 디코딩 (Base64)
            payload_compressed = base64.b64decode(record['data'])
            try:
                # CloudWatch Logs 데이터는 gzip으로 압축되어 전달됩니다.
                payload_uncompressed = gzip.decompress(payload_compressed).decode('utf-8')
                # logger.debug(f"Decompressed payload: {payload_uncompressed}") # 디버깅 시 유용
            except gzip.BadGzipFile:
                logger.warning(f"Record {record_id} data is not gzip compressed? Trying direct decode.")
                # 혹시 압축되지 않은 데이터가 올 경우 대비 (일반적이지 않음)
                payload_uncompressed = payload_compressed.decode('utf-8')
            except Exception as decomp_err:
                 logger.error(f"Failed to decompress/decode data for record {record_id}: {decomp_err}")
                 output_records.append({
                     'recordId': record_id,
                     'result': 'ProcessingFailed',
                     'data': record['data'] # 원본 데이터 반환
                 })
                 continue # 다음 레코드로 이동

            # 2. CloudWatch Logs 이벤트 형식 파싱 (압축 해제된 데이터 사용)
            cw_log_data = json.loads(payload_uncompressed) # payload_decoded 대신 payload_uncompressed 사용
            # logger.debug(f"CloudWatch Log Data: {cw_log_data}")

            # 3. 실제 RDSOSMetrics 데이터 추출 (message 필드)
            # CloudWatch Logs 이벤트는 여러 logEvents를 포함할 수 있습니다. 반복 처리 필요.
            processed_count = 0
            for log_event in cw_log_data.get('logEvents', []):
                message_str = log_event.get('message')
                if not message_str:
                    logger.warning(f"Log event in record {record_id} has empty message, skipping.")
                    continue

                # 4. RDSOSMetrics JSON 파싱
                try:
                    rds_metric_data = json.loads(message_str)
                    # logger.debug(f"Parsed RDS Metric Data: {rds_metric_data}")
                except json.JSONDecodeError as json_err:
                    logger.error(f"Failed to parse JSON message in record {record_id}, log event: {json_err}. Message: {message_str[:500]}...")
                    # 이 로그 이벤트 처리 실패. 다음 로그 이벤트로 넘어갈 수 있음.
                    # 또는 전체 레코드를 실패 처리할 수도 있음 (현재 로직 유지 시 아래 append 불필요)
                    continue # 다음 로그 이벤트 처리

                # 5. (선택 사항) 데이터 가공/정제
                # 예: 타임스탬프 형식 변경, 필드 이름 변경, 불필요 필드 제거 등
                # rds_metric_data['@timestamp'] = rds_metric_data.pop('timestamp') # 예시: 필드 이름 변경
                # OpenSearch는 일반적으로 @timestamp 필드를 사용합니다. CloudWatch Logs의 timestamp를 사용하는 것이 좋습니다.
                rds_metric_data['@timestamp'] = log_event.get('timestamp') # CloudWatch LogEvent의 timestamp 사용

                # 6. 변환된 데이터를 Base64로 다시 인코딩 (개별 로그 이벤트를 별도 레코드로 만들 경우)
                # Firehose는 보통 레코드 단위로 처리하므로, 여러 로그 이벤트를 하나의 레코드로 묶거나
                # 각 로그 이벤트를 별도의 레코드로 변환하여 반환해야 할 수 있습니다.
                # 여기서는 각 유효한 log event를 별도의 성공 레코드로 만듭니다.
                output_payload = json.dumps(rds_metric_data)
                output_data_encoded = base64.b64encode(output_payload.encode('utf-8')).decode('utf-8')

                # 각 로그 이벤트를 별도의 결과 레코드로 추가 (ID는 원본 레코드 ID 사용, Firehose가 처리)
                output_records.append({
                    'recordId': record_id, # 원본 레코드 ID 유지
                    'result': 'Ok',
                    'data': output_data_encoded
                })
                processed_count += 1

            # 해당 레코드의 모든 logEvents 처리 후, 처리된 것이 없으면 Dropped 처리 가능
            if processed_count == 0:
                 logger.warning(f"Record {record_id} contained no processable log events.")
                 # 원본 레코드를 Dropped 처리 (필요에 따라 ProcessingFailed 가능)
                 output_records.append({
                     'recordId': record_id,
                     'result': 'Dropped',
                     'data': record['data'] # 원본 데이터 반환 (선택 사항)
                 })


        except Exception as e:
            logger.error(f"Error processing record {record_id}: {e}", exc_info=True)
            # 처리 실패 시 'ProcessingFailed'로 표시하여 Firehose가 S3에 백업하도록 함
            output_records.append({
                'recordId': record_id,
                'result': 'ProcessingFailed',
                'data': record['data'] # 원본 데이터 반환
            })

    logger.info(f"Processed {len(event['records'])} input records. Outputting {len(output_records)} records.")

    # 반환 형식은 {'records': [...]} 여야 합니다.
    return {'records': output_records}

