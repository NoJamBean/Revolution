import json
import boto3
import gzip
import os
from urllib.request import Request, urlopen
from datetime import datetime
import logging

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')
opensearch_endpoint = os.environ['OPENSEARCH_ENDPOINT']
# index_prefix = os.environ.get('INDEX_PREFIX', 'cloudtrail') # 환경 변수에서 인덱스 접두사 가져오기 (선택 사항)

def lambda_handler(event, context):
    logger.info("Received event: " + json.dumps(event, indent=2))

    # S3 이벤트에서 버킷 이름과 파일 키 가져오기
    try:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        # URL-encoded 키 디코딩 (공백 등 특수 문자 처리)
        key = key.replace('+', ' ')
    except (KeyError, IndexError) as e:
        logger.error(f"Could not extract bucket/key from event: {e}")
        return {'statusCode': 400, 'body': json.dumps('Invalid S3 event format')}


    try:
        # S3에서 로그 파일 다운로드
        response = s3.get_object(Bucket=bucket, Key=key)
        content = response['Body'].read()

        # 압축 해제 (.gz)
        log_data_raw = gzip.decompress(content).decode('utf-8')
        log_data = json.loads(log_data_raw)

        records = log_data.get('Records', [])
        logger.info(f"Processing {len(records)} records from {key}")

        if not records:
            logger.info("No records to send.")
            return {'statusCode': 200, 'body': json.dumps('No records found in the file.')}

        # OpenSearch Bulk API 형식으로 데이터 준비
        bulk_data = ""
        for record in records:
            try:
                # 인덱스 이름 생성 (예: cloudtrail-YYYY-MM-DD)
                # eventTime 필드를 사용하여 날짜 결정 시도, 없으면 현재 시간 사용
                event_time_str = record.get('eventTime')
                if event_time_str:
                    try:
                        # ISO 8601 형식 파싱 시도 (예: '2025-04-16T14:30:00Z')
                        dt_obj = datetime.fromisoformat(event_time_str.replace('Z', '+00:00'))
                        index_date_str = dt_obj.strftime('%Y-%m-%d')
                    except ValueError:
                        logger.warning(f"Could not parse eventTime '{event_time_str}', using current date.")
                        index_date_str = datetime.utcnow().strftime('%Y-%m-%d')
                else:
                    index_date_str = datetime.utcnow().strftime('%Y-%m-%d')

                index_name = f"cloudtrail-{index_date_str}" # 날짜 기반 인덱스

                # Bulk API 메타데이터 라인
                bulk_data += json.dumps({"index": {"_index": index_name}}) + "\\n"
                # 실제 로그 레코드 라인
                bulk_data += json.dumps(record) + "\\n"
            except Exception as e:
                logger.error(f"Error processing individual record: {e}. Record: {json.dumps(record)}")
                # 개별 레코드 오류 시 다음 레코드로 계속 진행 (선택적)


        # OpenSearch로 데이터 전송 (Bulk API 사용)
        # 중요: 실제 환경에서는 requests 라이브러리 사용 및 오류 처리 강화 권장
        # 중요: FGAC 사용 시 인증 헤더 추가 필요 (예: HTTP Basic Auth 또는 SigV4)
        url = f"https://{opensearch_endpoint}/_bulk"
        headers = {"Content-Type": "application/x-ndjson"}

        req = Request(url, data=bulk_data.encode('utf-8'), headers=headers, method='POST')
        with urlopen(req) as response:
            response_status = response.status
            response_body = response.read().decode('utf-8')
            logger.info(f"OpenSearch response status: {response_status}")
            # logger.debug(f"OpenSearch response body: {response_body}") # 상세 응답 필요 시 DEBUG 레벨 사용

            # 응답 내용 확인 (오류 확인 등)
            if response_status >= 300:
                 logger.error(f"OpenSearch request failed with status {response_status}: {response_body}")

            response_json = json.loads(response_body)
            if response_json.get('errors'):
                error_count = 0
                logger.warning("Errors reported by OpenSearch Bulk API:")
                # 오류 상세 로깅 (샘플)
                for item in response_json.get('items', []):
                    if 'error' in item.get('index', {}):
                         error_count += 1
                         # 로그가 너무 길어지는 것을 방지하기 위해 일부 오류만 로깅할 수 있음
                         if error_count < 10:
                            logger.warning(f"  Item Error: {item['index']['error']}")
                if error_count >= 10:
                    logger.warning(f"  ... and {error_count - 9} more errors.")


        logger.info(f"Successfully processed {key} and attempted to send {len(records)} records.")
        return {'statusCode': 200, 'body': json.dumps('Successfully processed logs.')}

    except json.JSONDecodeError as e:
        logger.error(f"Error decoding JSON from file {key}: {e}")
        # JSON 파싱 오류 시 재시도하지 않도록 처리 가능
        return {'statusCode': 400, 'body': json.dumps('Invalid JSON format in log file.')}
    except Exception as e:
        logger.error(f"Error processing file {key} from bucket {bucket}: {e}", exc_info=True)
        raise e # 그 외 오류 발생 시 Lambda 재시도 유도

