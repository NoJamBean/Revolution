import json
import boto3
import gzip
import os
import requests # Layer 에 포함된 라이브러리 import
from aws_requests_auth.aws_auth import AWSRequestsAuth # Layer 에 포함된 라이브러리 import
from datetime import datetime
import logging

# 로깅 설정
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')
opensearch_endpoint = os.environ['OPENSEARCH_ENDPOINT']
# 현재 리전 가져오기 (SigV4 서명에 필요)
aws_region = os.environ.get('AWS_REGION', 'ap-northeast-2') # Lambda 환경 변수에서 가져오거나 기본값 사용

# --- SigV4 인증 설정 ---
# Lambda 실행 역할의 자격 증명을 자동으로 사용
credentials = boto3.Session().get_credentials()
aws_auth = AWSRequestsAuth(aws_access_key=credentials.access_key,
                           aws_secret_access_key=credentials.secret_key,
                           aws_token=credentials.token, # 임시 자격 증명 토큰 포함
                           aws_host=opensearch_endpoint,
                           aws_region=aws_region,
                           aws_service='es') # OpenSearch 서비스 이름 'es'

def lambda_handler(event, context):
    logger.info("Received event: " + json.dumps(event, indent=2))

    # S3 이벤트에서 버킷 이름과 파일 키 가져오기
    try:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        # URL-encoded 키 디코딩 (공백 등 특수 문자 처리)
        key = key.replace('+', ' ')
    except (KeyError, IndexError) as e:
        logger.error(f"Could not extract bucket/key from event: {e}")
        return {'statusCode': 400, 'body': json.dumps('Invalid S3 event format')}

    # --- 안정성을 위해 try-except 블록 복구 ---
    try:
        # S3에서 로그 파일 다운로드
        response = s3.get_object(Bucket=bucket, Key=key)
        content = response['Body'].read()

        # 압축 해제 (.gz)
        log_data_raw = gzip.decompress(content).decode('utf-8')
        log_data = json.loads(log_data_raw)

        records = log_data.get('Records', [])
        logger.info(f"Processing {len(records)} records from {key}")

        if not records:
            logger.info("No records to send.")
            return {'statusCode': 200, 'body': json.dumps('No records found in the file.')}

        # OpenSearch Bulk API 형식으로 데이터 준비
        bulk_data = ""
        for record in records:
            try:
                # 인덱스 이름 생성 (예: cloudtrail-YYYY-MM-DD)
                event_time_str = record.get('eventTime')
                if event_time_str:
                    try:
                        dt_obj = datetime.fromisoformat(event_time_str.replace('Z', '+00:00'))
                        index_date_str = dt_obj.strftime('%Y-%m-%d')
                    except ValueError:
                        logger.warning(f"Could not parse eventTime '{event_time_str}', using current date.")
                        index_date_str = datetime.utcnow().strftime('%Y-%m-%d')
                else:
                    index_date_str = datetime.utcnow().strftime('%Y-%m-%d')

                index_name = f"cloudtrail-{index_date_str}" # 날짜 기반 인덱스

                # Bulk API 메타데이터 라인
                bulk_data += json.dumps({"index": {"_index": index_name}}) + "\\n"
                # 실제 로그 레코드 라인
                bulk_data += json.dumps(record) + "\\n"
            except Exception as e:
                logger.error(f"Error processing individual record: {e}. Record: {json.dumps(record)}")

        # OpenSearch로 데이터 전송 (requests 및 SigV4 사용)
        url = f"https://{opensearch_endpoint}/_bulk"
        headers = {"Content-Type": "application/x-ndjson"}

        # 'requests' 라이브러리 사용 및 aws_auth 로 SigV4 서명 적용
        r = requests.post(url, auth=aws_auth, data=bulk_data.encode('utf-8'), headers=headers)

        logger.info(f"OpenSearch response status: {r.status_code}")
        # logger.debug(f"OpenSearch response body: {r.text}") # 상세 응답 필요 시 DEBUG 레벨 사용

        # 응답 내용 확인 (오류 확인 등)
        if r.status_code >= 300:
             logger.error(f"OpenSearch request failed with status {r.status_code}: {r.text}")

        response_json = r.json() # requests 는 json() 메소드 제공
        if response_json.get('errors'):
            error_count = 0
            logger.warning("Errors reported by OpenSearch Bulk API:")
            # 오류 상세 로깅 (샘플)
            for item in response_json.get('items', []):
                if 'error' in item.get('index', {}):
                     error_count += 1
                     # 로그가 너무 길어지는 것을 방지하기 위해 일부 오류만 로깅할 수 있음
                     if error_count < 10:
                        logger.warning(f"  Item Error: {item['index']['error']}")
            if error_count >= 10:
                logger.warning(f"  ... and {error_count - 9} more errors.")


        logger.info(f"Successfully processed {key} and attempted to send {len(records)} records.")
        return {'statusCode': 200, 'body': json.dumps('Successfully processed logs.')}

    except json.JSONDecodeError as e:
        logger.error(f"Error decoding JSON from file {key}: {e}")
        # JSON 파싱 오류 시 재시도하지 않도록 처리 가능
        return {'statusCode': 400, 'body': json.dumps('Invalid JSON format in log file.')}
    except Exception as e:
        logger.error(f"Error processing file {key} from bucket {bucket}: {e}", exc_info=True)
        raise e # 그 외 오류 발생 시 Lambda 재시도 유도
    # --- 여기까지 try-except 블록 ---

